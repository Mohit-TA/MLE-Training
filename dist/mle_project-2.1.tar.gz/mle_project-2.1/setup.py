from setuptools import setup

setup(
    name='mle_project',
    version='2.1',
    install_requires=[
        'requests',
        'importlib-metadata; python_version == "3.11.4"',
    ],
)